
unsigned int my_random (unsigned long int, unsigned long int);
char NOP_char[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
