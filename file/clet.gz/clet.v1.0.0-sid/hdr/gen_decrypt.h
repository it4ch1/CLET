unsigned int my_random (unsigned long int, unsigned long int);
#define MAX_KINDOF_INST 5
