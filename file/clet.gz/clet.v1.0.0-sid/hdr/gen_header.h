unsigned int my_random (unsigned long int, unsigned long int);
